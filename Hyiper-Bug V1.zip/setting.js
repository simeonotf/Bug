
const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const Fichan = new require('./lib/functions')

// System
global.baileys = require('@whiskeysockets/baileys')
global.usePairingCode = true

global.saluran = ''
    global.idsal = "0@newsletter" // opsional ID saluran
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'karz' //ubah jadi nama mu, note tanda ' gausah di hapus!
global.owner = ['6282172794332','6285723798369'] // ubah aja pake nomor lu

// bot
global.botname = 'Karz and FluXz' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = 'ᴄʀᴇᴀᴛᴇᴅ ʙʏ FluXz and Karz' // ubah aja ini nama sticker
global.author = `At ${hariini}\n${time}` // ubah aja ini nama sticker
global.hiasan = `	◦  `
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'karzsession' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.gris = '`'
global.wm = `K A R Z  B O T Z`
global.namaStore = 'Krz And FluXz'
global.ownerStore = 'Karz And FluXz'
global.autobio = false // AutoBio
global.autoread = true //autoread

// apikey panel
global.footer2 = Styles('simple whatsapp bot made by karz')
global.domain = 'https://panelardipay.webprivate.my.id' // Isi Domain Lu
global.apikey2 = 'ptlc_xK4LKRXKTfrOjmypbJ1xhHtQeNiRGt24oOTYwpspkiG' // Isi Apikey Plta Lu
global.capikey2 = 'ptla_xMtAsVIiC0W89eSQENJcT6lGSDQq22vLU6YJOp4Btxw' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.apilinode = ''
global.apitokendo = ''

// system
global.Func = Fichan
global.systemN = `*[ System Notice ]*`
global.mess = {
    ban: Styles('*[ System Access Failed ]* you are banned by the owner'),
    badm: Styles('*[ System Notice ]* please add bot *admin*'),
    regis: Styles(`*[ System Access Failed ]*\n\nKamu belum daftar!\nSilahkan daftar dengan cara *.daftar nama.umur*`),
    premium: Styles('*[ System Notice ]* this only premium user'),
    search: Styles('🔍 *Search for server. . .*'),
    done: Styles('Done Ga Bang?? Done...'),
    success: Styles('*[ Loaded Success ]*'),
    admin: Styles('*[ System Notice ]* for *admin!* not *npc*'),
    owner: Styles('*[ System Access Failed ]* Access Denied'),
    group: Styles('*[ System Notice ]* Use this in group chat!'),
    private: Styles('*[ System Notice ]* Use this in private chat!'),
    bot: Styles('*[ System Notice ]* Only Bot user'),
    wait: Styles('*[ Loading ]* Please Wait'),
    getdata: Styles('Scraping metadata . . .'),
    fail: Styles('Can\'t get metadata!'),
    error: Styles('*[ System Failed ]* Error, please contact the owner'),
    errorF: Styles('*[ System Failed ]* Sorry this feature is in error.'),
}
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})